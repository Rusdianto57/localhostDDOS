require("prompt-sync")
const ps = require("prompt-sync");
const prompt = ps();
let cn = Math.floor((Math.random() * 10000000) + 1);
console.log("Your verification number is - " + cn)
let i
i = prompt("Enter your verification number")
while(i!=cn){
i = prompt("Your number is incorrect, try again")
}
console.log("Your number is correct")

let host = prompt("What is ip of your server? ")
let port = prompt("What is port of your server? default is 25565::: ")
let spam = prompt("Write the message here which should be spammed..")

const mineflayer = require('mineflayer');

let botArgs = {
  host: host,
  port: port,
  version: '1.18.1'
};

class MCBot {

  // Constructor
  constructor(username) {
    this.username = username;
    this.host = botArgs["host"];
    this.port = botArgs["port"];
    this.version = botArgs["version"];

    this.initBot();
  }

  // Init bot instance
  initBot() {
    this.bot = mineflayer.createBot({
      "username": this.username,
      "host": this.host,
      "port": this.port,
      "version": this.version
    });

    this.initEvents()
  }

  // Init bot events
  initEvents() {
    this.bot.on('login', () => {
      let botSocket = this.bot._client.socket;
      console.log(`[${this.username}] Logged in to ${botSocket.server ? botSocket.server : botSocket._host}`);
    });

    this.bot.on('end', (reason) => {
      console.log(`[${this.username}] Disconnected: ${reason}`);

      if (reason == "disconnect.quitting") {
        return
      }

      // Attempt to reconnect
      setTimeout(() => this.initBot(), 1000);
    });

    this.bot.on('spawn', async () => {
      console.log(`[${this.username}] Spawned in`);
      await this.bot.waitForTicks(0);
      this.bot.chat("/register anonyone_force anonyone_force");
      await this.bot.waitForTicks(0);
      this.bot.chat("/login anonyone_force");
      await this.bot.waitForTicks(0);
      this.bot.chat("/register anonyone_force");
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
      await this.bot.waitForTicks(0);
      this.bot.chat(spam);
      
    });

    this.bot.on('error', (err) => {
      if (err.code == 'ECONNREFUSED') {
        console.log(`[${this.username}] Failed to connect to ${err.address}:${err.port}`)
      }
      else {
        console.log(`[${this.username}] Unhandled error: ${err}`);
      }
    });
  }
}
let n = prompt("How many bots do you want to send?")
let usernamee = prompt("What should be the bot's username?(Under 14 characters)(should not contain spaces)(should not contain special symbols)")
let bots = [];
for(var num = 0; num < n; num++) {
    bots.push(new MCBot(usernamee+num))
}